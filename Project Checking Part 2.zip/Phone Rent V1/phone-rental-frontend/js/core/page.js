// ============================================================
// DiaLux — core/page.js
// Shared page bootstrap. Each page module calls bootPage() with its
// nav key and a render function; everything common (chrome, session,
// data hydration, 3D effects, reveal observer) happens here once.
// ============================================================

import * as fx from '../3d-enhancements.js';
import { mountChrome, initReveal, updateCartBadge, bindImageFallbacks, toast } from './ui.js';
import { restoreSession, initAcctMenu, renderAcctButton } from './auth.js';
import { state, hydrate } from './state.js';

/**
 * Re-apply the effects that depend on freshly rendered DOM. Safe to call
 * after every re-render — each helper guards itself with a data-*-bound
 * attribute.
 *
 * Deliberately excludes initPageTransitions(), which attaches an
 * unguarded document-level click listener and would stack a new handler
 * on every call.
 */
export function refreshFx() {
  fx.initTilt('.tilt-card');
  fx.initFlipCards('.flip-card');
  fx.initRipple('.btn, .add-cart-btn, .view-details-btn');
  fx.initStagger('.stagger');
  bindImageFallbacks();
  initReveal();
}

/** Warn once, at the top of the page, when the API is unreachable. */
function renderOfflineBanner() {
  if (!state.offline) return;
  const main = document.querySelector('main .container') || document.querySelector('main');
  if (!main || document.getElementById('offlineBanner')) return;

  const el = document.createElement('div');
  el.id = 'offlineBanner';
  el.className = 'return-reminder';
  el.style.marginBottom = '20px';
  el.textContent = 'Cannot reach the DiaLux server — the catalog is unavailable. Start the backend with "npm run dev" and reload this page.';
  main.prepend(el);
}

/**
 * @param {string} active  nav key: home | products | cart | profile | admin
 * @param {() => (void|Promise<void>)} render  page-specific rendering
 */
export async function bootPage(active, render) {
  document.body.dataset.page = active;

  mountChrome(active);
  initAcctMenu();

  fx.markSupport();
  fx.initPageTransitions();
  fx.initHeroRig();

  // Settle the session first, then load data — pages that branch on auth
  // state (profile, admin) and the cart's backing store both depend on it.
  await restoreSession();
  await hydrate();
  renderAcctButton();

  try {
    await render();
  } catch (err) {
    console.error(`[DiaLux] ${active} page failed to render:`, err);
    toast('Something went wrong rendering this page', 'error');
  }

  renderOfflineBanner();
  updateCartBadge();
  refreshFx();
}
