// ============================================================
// DiaLux — core/ui.js
// Formatters, toasts, shared header/footer, and the scroll-reveal
// observer. Every page imports from here so the chrome is defined
// once instead of being copy-pasted into five HTML files.
// ============================================================

import { state, cartCount } from './state.js';

/* ---------------- formatters ---------------- */

export function peso(n) {
  return `₱${Math.round(Number(n) || 0).toLocaleString('en-PH')}`;
}

export function escapeHtml(s = '') {
  return String(s).replace(/[&<>'"]/g, c => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]
  ));
}

export function formatDate(v) {
  if (!v) return '—';
  const d = new Date(String(v).length <= 10 ? `${v}T00:00:00` : v);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function titleCase(s = '') {
  return String(s).replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}

/* ---------------- device iconography ---------------- */

export const icons = {
  phone:  '<svg viewBox="0 0 24 24" fill="none"><rect x="7" y="2" width="10" height="20" rx="2.5" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="18.4" r="1" fill="currentColor"/></svg>',
  tablet: '<svg viewBox="0 0 24 24" fill="none"><rect x="4" y="3" width="16" height="18" rx="2.5" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="18" r="0.8" fill="currentColor"/></svg>',
  laptop: '<svg viewBox="0 0 24 24" fill="none"><rect x="4" y="4" width="16" height="11" rx="1.5" stroke="currentColor" stroke-width="1.6"/><path d="M2 19h20" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
  wifi:   '<svg viewBox="0 0 24 24" fill="none"><path d="M4 9a13 13 0 0 1 16 0M7 12.5a8.5 8.5 0 0 1 10 0M10 16a4 4 0 0 1 4 0" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><circle cx="12" cy="19.2" r="1" fill="currentColor"/></svg>',
};

export const catLabels = {
  phone: 'Smartphone', tablet: 'Tablet', laptop: 'Laptop', wifi: 'Portable Wi-Fi',
};

export function catLabel(c) { return catLabels[c] || c; }
export function categoryIcon(cat) { return icons[cat] || icons.phone; }

export function gradeClass(g) {
  return g === 'Like New' ? 'tag-a' : g === 'Good' ? 'tag-b' : 'tag-c';
}

export function statusClass(status) {
  return `status-${String(status || 'pending').toLowerCase()}`;
}

export function stockLine(stock) {
  if (stock === 0) return '<div class="stock-line out">Out of stock</div>';
  if (stock <= 2)  return `<div class="stock-line low">Only ${stock} left</div>`;
  return `<div class="stock-line">${stock} available</div>`;
}

/* ---------------- toast ---------------- */

export function toast(msg, kind = 'ok') {
  const box = document.getElementById('toast');
  if (!box) { console.log('[toast]', msg); return; }

  const el = document.createElement('div');
  el.className = 'toast-item';
  el.setAttribute('role', 'status');
  const mark = kind === 'error'
    ? '<path d="M12 8v5M12 16.5v.5" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.8"/>'
    : '<path d="M5 12l4 4L19 6" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>';
  el.innerHTML = `<svg viewBox="0 0 24 24" fill="none" style="${kind === 'error' ? 'color:#D14343' : ''}">${mark}</svg>${escapeHtml(msg)}`;

  box.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'all .25s';
    el.style.opacity = '0';
    el.style.transform = 'translateX(20px)';
    setTimeout(() => el.remove(), 250);
  }, 2600);
}

/* ---------------- empty state ---------------- */

export function emptyState(title, body = '', action = '') {
  return `
    <div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none"><rect x="3" y="6" width="18" height="13" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M3 10h18M8 3v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
      <h3 style="margin-bottom:8px;">${escapeHtml(title)}</h3>
      ${body ? `<p style="max-width:420px;margin:0 auto 18px;">${escapeHtml(body)}</p>` : ''}
      ${action}
    </div>`;
}

/* ---------------- product image fallback ----------------
   assets/products/ has no artwork yet, so every <img> 404s.
   Rather than show a broken-image glyph, swap in the category
   icon on error.
--------------------------------------------------------- */

export function bindImageFallbacks(root = document) {
  root.querySelectorAll('img[data-cat]:not([data-fallback-bound])').forEach(img => {
    img.dataset.fallbackBound = '1';
    img.addEventListener('error', () => {
      const holder = img.parentElement;
      if (!holder) return;
      holder.classList.add('thumb-fallback');
      holder.innerHTML = categoryIcon(img.dataset.cat);
    }, { once: true });
  });
}

/* ---------------- scroll reveal ----------------
   styles.css defines .reveal { opacity:0 } and .reveal.in
   { opacity:1 } but nothing ever added .in — so every element
   marked .reveal stayed permanently invisible. This supplies
   the missing observer.
--------------------------------------------------------- */

const prefersReducedMotion = () =>
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export function initReveal(selector = '.reveal') {
  const els = [...document.querySelectorAll(selector)].filter(el => !el.dataset.revealBound);
  if (!els.length) return;

  if (prefersReducedMotion() || !('IntersectionObserver' in window)) {
    els.forEach(el => { el.dataset.revealBound = '1'; el.classList.add('in'); });
    return;
  }

  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      e.target.classList.add('in');
      io.unobserve(e.target);
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -8% 0px' });

  els.forEach(el => { el.dataset.revealBound = '1'; io.observe(el); });
}

/* ---------------- shared chrome ----------------
   Injected into #siteHeader / #siteFooter on every page. Keeps
   the nav, account menu and cart badge identical everywhere and
   guarantees #acctBtn exists — its absence used to throw a
   TypeError and abort init on admin.html and profile.html.

   The dashboard link is added dynamically once the session settles,
   so only admins ever see it — non-admin users get a clean nav with
   no hint that an admin area exists.
--------------------------------------------------------- */

/** Insert the dashboard link after Profile when an admin signs in. */
function syncAdminNav() {
  const isAdminUser = state.user?.role === 'admin';

  // Desktop nav.
  const list = document.querySelector('.nav-links');
  if (list) {
    list.querySelector('.nav-admin')?.remove();
    if (isAdminUser) {
      const li = document.createElement('li');
      li.className = 'nav-admin';
      const a = document.createElement('a');
      a.href = '/admin.html';
      a.textContent = 'Dashboard';
      if (document.body.dataset.page === 'admin') a.className = 'active';
      li.appendChild(a);
      list.appendChild(li);
    }
  }

  // Account dropdown — .nav-links is hidden under 900px, so this is the
  // only route to the dashboard on phones and tablets.
  const menu = document.getElementById('acctMenu');
  if (menu) {
    menu.querySelector('.menu-admin')?.remove();
    if (isAdminUser) {
      const a = document.createElement('a');
      a.className = 'menu-admin';
      a.href = '/admin.html';
      a.textContent = 'Admin dashboard';
      menu.insertBefore(a, menu.querySelector('#signOutBtn'));
    }
  }
}

// Customer-facing nav. The dashboard is deliberately absent — see
// syncAdminNav() above.
const NAV = [
  { href: '/',              page: 'home',     label: 'Home' },
  { href: '/products.html', page: 'products', label: 'Devices' },
  { href: '/cart.html',     page: 'cart',     label: 'Cart' },
  { href: '/profile.html',  page: 'profile',  label: 'Profile' },
];

const LOGO_SVG = '<svg viewBox="0 0 24 24" fill="none"><rect x="7" y="2" width="10" height="20" rx="2.5" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="18.4" r="1.2" fill="currentColor"/></svg>';

function headerMarkup(active) {
  const links = NAV.map(n =>
    `<li><a href="${n.href}"${n.page === active ? ' class="active"' : ''}>${n.label}</a></li>`
  ).join('');

  return `
  <header class="glass-nav">
    <nav class="container">
      <a class="logo" href="/" aria-label="DiaLux home">
        ${LOGO_SVG}<span>DiaLux</span>
      </a>
      <ul class="nav-links">${links}</ul>
      <div class="nav-right">
        <a class="icon-btn" href="/cart.html" aria-label="Cart">
          <svg viewBox="0 0 24 24" fill="none"><path d="M3 4h2l2.4 11.2a1.6 1.6 0 0 0 1.6 1.3h8.4a1.6 1.6 0 0 0 1.6-1.3L21 8H6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><circle cx="10" cy="20" r="1.3" fill="currentColor"/><circle cx="17" cy="20" r="1.3" fill="currentColor"/></svg>
          <span class="badge" id="cartBadge">0</span>
        </a>
        <div class="acct-wrap">
          <button id="acctBtn" class="acct-btn" aria-haspopup="true" aria-expanded="false">Sign in</button>
          <div id="acctMenu" class="acct-menu">
            <a href="/profile.html">My account</a>
            <a href="/profile.html#orders">My rentals</a>
            <button type="button" id="signOutBtn">Sign out</button>
          </div>
        </div>
      </div>
    </nav>
  </header>`;
}

function footerMarkup() {
  return `
  <footer>
    <div class="container footer-grid">
      <div class="footer-brand">
        <div class="logo">${LOGO_SVG}<span>DiaLux</span></div>
        <p>On-demand tech rentals — smartphones, tablets, laptops &amp; pocket Wi-Fi.</p>
      </div>
      <div class="footer-col">
        <h5>Platform</h5>
        <a href="/products.html">Devices</a>
        <a href="/cart.html">Cart</a>
        <a href="/profile.html">My account</a>
      </div>
      <div class="footer-col">
        <h5>Company</h5>
        <a href="/">About</a>
        <a href="/">Team</a>
        <a href="/">Contact</a>
      </div>
      <div class="footer-col">
        <h5>Support</h5>
        <a href="/">Help center</a>
        <a href="/">Terms</a>
        <a href="/">Privacy</a>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© 2026 DiaLux · A student project for IT 009 · TIP QC</span>
    </div>
  </footer>`;
}

/** Render header + footer into their mount points. */
export function mountChrome(active) {
  const h = document.getElementById('siteHeader');
  const f = document.getElementById('siteFooter');
  if (h) h.innerHTML = headerMarkup(active);
  if (f) f.innerHTML = footerMarkup();
  updateCartBadge();
}

/**
 * Reflect the signed-in role in the nav — call after the session
 * settles (restoreSession) and again after login/logout, since the
 * header is already mounted by then.
 */
export function refreshChrome() {
  syncAdminNav();
  updateCartBadge();
}

export function updateCartBadge() {
  const badge = document.getElementById('cartBadge');
  if (!badge) return;
  const n = cartCount();
  badge.textContent = String(n);
  badge.style.display = n ? '' : 'none';
}
