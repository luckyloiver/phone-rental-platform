// ============================================================
// DiaLux — core/state.js
// In-memory store, hydrated from the API.
//
// The cart has two backing stores:
//   • signed in  → the server's Cart collection (authoritative)
//   • signed out → localStorage, priced client-side
// Both are normalised to the same shape, so pages never branch on it.
// On sign-in the guest cart is merged into the server cart.
// ============================================================

import { productsApi, cartApi, ordersApi, usersApi, ApiError } from './api.js';

const GUEST_CART_KEY = 'phonerent-guest-cart';
const GUEST_DATES_KEY = 'phonerent-guest-dates';

export const CATEGORIES = [
  { key: 'all',    label: 'All devices' },
  { key: 'phone',  label: 'Smartphones' },
  { key: 'tablet', label: 'Tablets' },
  { key: 'laptop', label: 'Laptops' },
  { key: 'wifi',   label: 'Pocket Wi-Fi' },
];

export const GRADES = ['Like New', 'Good', 'Fair'];
export const PLANS = ['Daily', 'Weekly', 'Monthly'];
export const PLAN_KEY  = { Daily: 'daily', Weekly: 'weekly', Monthly: 'monthly' };
export const PLAN_DAYS = { Daily: 1, Weekly: 7, Monthly: 30 };
export const DELIVERY_FEE = 150;

// The six stages shown in the customer-facing order timeline.
export const STAGE_LABELS = ['Booked', 'Paid', 'Preparing', 'Shipped', 'Delivered', 'Completed'];

// Where each status sits on that six-stage timeline.
export const STATUS_STAGE = {
  pending: 0, 'payment-confirmed': 1, approved: 1, preparing: 2,
  shipped: 3, delivered: 4, active: 4, 'return-requested': 4,
  inspection: 4, refunded: 5, completed: 5, cancelled: 0,
};

export const ORDER_STATUSES = [
  'pending', 'payment-confirmed', 'approved', 'preparing', 'shipped',
  'delivered', 'active', 'return-requested', 'inspection', 'refunded',
  'completed', 'cancelled',
];

// Statuses at which a device has reached the customer — the point from which
// they may review it. Mirrors QUALIFYING_REVIEW_STATUSES in the backend; the
// server re-checks this authoritatively, so this is just for showing the form.
export const REVIEWABLE_STATUSES = ['delivered', 'active', 'return-requested', 'inspection', 'completed'];

const EMPTY_CART = { lines: [], count: 0, rent: 0, deposit: 0, delivery: 0, total: 0 };

export const state = {
  products: [],
  cart: { ...EMPTY_CART },
  orders: [],
  user: null,
  ready: false,
  offline: false,   // true when the API could not be reached
};

/* ---------------- guest cart persistence ---------------- */

function readGuestCart() {
  try {
    const raw = JSON.parse(localStorage.getItem(GUEST_CART_KEY) || '[]');
    return Array.isArray(raw) ? raw.filter(i => i && i.productId) : [];
  } catch { return []; }
}

function writeGuestCart(items) {
  try { localStorage.setItem(GUEST_CART_KEY, JSON.stringify(items)); } catch { /* ignore */ }
}

export function clearGuestCart() {
  writeGuestCart([]);
  try { localStorage.removeItem(GUEST_DATES_KEY); } catch { /* ignore */ }
}

/* ---------------- guest rental dates ---------------- */

function readGuestDates() {
  try {
    const raw = JSON.parse(localStorage.getItem(GUEST_DATES_KEY) || '{}');
    return {
      startDate: typeof raw.startDate === 'string' ? raw.startDate : '',
      endDate:   typeof raw.endDate === 'string' ? raw.endDate : '',
    };
  } catch { return { startDate: '', endDate: '' }; }
}

function writeGuestDates(startDate, endDate) {
  try {
    localStorage.setItem(GUEST_DATES_KEY, JSON.stringify({ startDate, endDate }));
  } catch { /* ignore */ }
}

/* ---------------- pricing ---------------- */

export function productById(id) {
  return state.products.find(p => p.id === String(id));
}

export function rateFor(p, plan) {
  return p?.[PLAN_KEY[plan] || 'weekly'] || 0;
}

/**
 * Whole calendar days between two YYYY-MM-DD dates, minimum 1.
 * Sep 1 → Sep 8 = 7; same day (or invalid) = 1.
 */
export function daysBetween(startDate, endDate) {
  const a = Date.parse(`${startDate}T00:00:00Z`);
  const b = Date.parse(`${endDate}T00:00:00Z`);
  if (Number.isNaN(a) || Number.isNaN(b)) return 1;
  return Math.max(1, Math.round((b - a) / 86400000));
}

/**
 * Cheapest rent for `days` across the daily/weekly/monthly tiers, overshoot
 * allowed. MUST stay identical to bestValue() in the backend's constants.js
 * so the cart total equals the amount charged at checkout.
 */
export function bestValue(p, days) {
  const n = Math.max(1, Math.ceil(Number(days) || 1));
  const tiers = [
    [1, Number(p.daily) || 0],
    [7, Number(p.weekly) || 0],
    [30, Number(p.monthly) || 0],
  ].filter(t => t[1] > 0);
  if (!tiers.length) return 0;

  const dp = new Array(n + 1).fill(Infinity);
  dp[0] = 0;
  for (let i = 1; i <= n; i++) {
    for (const [len, rate] of tiers) {
      dp[i] = Math.min(dp[i], dp[Math.max(0, i - len)] + rate);
    }
  }
  return dp[n];
}

export function brands() {
  return [...new Set(state.products.map(p => p.brand))].sort();
}

/** Price a guest cart from the loaded catalog, matching the server shape. */
function priceGuestCart(items) {
  const { startDate, endDate } = readGuestDates();
  const days = (startDate && endDate) ? daysBetween(startDate, endDate) : 7;

  const lines = items.map(i => {
    const p = productById(i.productId);
    if (!p) return null;
    const rate = bestValue(p, days);
    const qty = Math.max(1, Math.min(Number(i.qty) || 1, p.stock || 1));
    return {
      productId: p.id,
      name: p.name,
      cat: p.cat,
      brand: p.brand,
      grade: p.grade,
      image: p.image,
      stock: p.stock,
      plan: i.plan,
      qty,
      rate,
      deposit: p.deposit,
      days,
      rentSubtotal: rate * qty,
      depositSubtotal: p.deposit * qty,
    };
  }).filter(Boolean);

  const rent = lines.reduce((s, l) => s + l.rentSubtotal, 0);
  const deposit = lines.reduce((s, l) => s + l.depositSubtotal, 0);
  const delivery = lines.length ? DELIVERY_FEE : 0;

  return {
    lines,
    count: lines.reduce((s, l) => s + l.qty, 0),
    startDate, endDate, days,
    rent, deposit, delivery,
    total: rent + deposit + delivery,
  };
}

function refreshGuestCart() {
  const items = readGuestCart();
  state.cart = priceGuestCart(items);
  // Drop lines whose product vanished from the catalog.
  if (state.cart.lines.length !== items.length) {
    writeGuestCart(state.cart.lines.map(l => ({ productId: l.productId, plan: l.plan, qty: l.qty })));
  }
  return state.cart;
}

export function cartCount() {
  return state.cart.count || 0;
}

/* ---------------- hydration ---------------- */

export async function loadProducts(params) {
  const data = await productsApi.list(params);
  state.products = data.products || [];
  return state.products;
}

/**
 * Load everything the current page might need. Products always; cart and
 * orders only when signed in. Never throws — sets state.offline instead,
 * so a dead backend degrades rather than blanking the page.
 */
export async function hydrate() {
  try {
    await loadProducts();
    state.offline = false;
  } catch (err) {
    state.offline = true;
    state.products = [];
    console.error('[DiaLux] could not load catalog:', err.message);
  }

  if (state.user) {
    try {
      state.cart = await cartApi.get();
    } catch {
      state.cart = { ...EMPTY_CART };
    }
    try {
      const data = await ordersApi.mine();
      state.orders = data.orders || [];
    } catch {
      state.orders = [];
    }
  } else {
    refreshGuestCart();
    state.orders = [];
  }

  state.ready = true;
  return state;
}

/* ---------------- cart mutations ----------------
   All return { ok, error } and never throw, so callers can render an
   error toast without a try/catch at every call site.
--------------------------------------------------------- */

function fail(err) {
  const message = err instanceof ApiError ? err.message : (err?.message || 'Something went wrong');
  return { ok: false, error: message };
}

export async function addToCart(productId, plan = 'Weekly', qty = 1) {
  const product = productById(productId);
  if (!product) return { ok: false, error: 'Device not found' };
  if (product.stock === 0) return { ok: false, error: `${product.name} is out of stock` };

  if (state.user) {
    try {
      state.cart = await cartApi.addItem(productId, plan, qty);
      return { ok: true, product };
    } catch (err) { return fail(err); }
  }

  const items = readGuestCart();
  const line = items.find(i => i.productId === productId && i.plan === plan);
  const already = line ? line.qty : 0;
  if (already + qty > product.stock) {
    return {
      ok: false,
      error: `Only ${product.stock} unit${product.stock === 1 ? '' : 's'} of ${product.name} available`,
    };
  }

  if (line) line.qty = already + qty;
  else items.push({ productId, plan, qty });

  writeGuestCart(items);
  refreshGuestCart();
  return { ok: true, product };
}

export async function updateCartLine(productId, plan, patch) {
  if (state.user) {
    try {
      state.cart = await cartApi.updateItem(productId, plan, patch);
      return { ok: true };
    } catch (err) { return fail(err); }
  }

  const items = readGuestCart();
  const line = items.find(i => i.productId === productId && i.plan === plan);
  if (!line) return { ok: false, error: 'Item not in cart' };

  const product = productById(productId);

  if (patch.newPlan && patch.newPlan !== plan) {
    const existing = items.find(i => i.productId === productId && i.plan === patch.newPlan);
    if (existing) {
      existing.qty += line.qty;
      items.splice(items.indexOf(line), 1);
    } else {
      line.plan = patch.newPlan;
    }
  }

  if (patch.qty !== undefined) {
    const target = items.find(i => i.productId === productId && i.plan === (patch.newPlan || plan));
    const wanted = Math.round(Number(patch.qty));
    if (!Number.isFinite(wanted) || wanted < 1) return { ok: false, error: 'Quantity must be 1 or more' };
    if (product && wanted > product.stock) {
      return { ok: false, error: `Only ${product.stock} unit${product.stock === 1 ? '' : 's'} available` };
    }
    if (target) target.qty = wanted;
  }

  writeGuestCart(items);
  refreshGuestCart();
  return { ok: true };
}

export async function removeCartLine(productId, plan) {
  if (state.user) {
    try {
      state.cart = await cartApi.removeItem(productId, plan);
      return { ok: true };
    } catch (err) { return fail(err); }
  }

  const items = readGuestCart().filter(i => !(i.productId === productId && i.plan === plan));
  writeGuestCart(items);
  refreshGuestCart();
  return { ok: true };
}

export async function emptyCart() {
  if (state.user) {
    try {
      state.cart = await cartApi.clear();
      return { ok: true };
    } catch (err) { return fail(err); }
  }
  clearGuestCart();
  refreshGuestCart();
  return { ok: true };
}

/**
 * Set the rental window that prices the whole cart. Signed-in carts persist
 * the dates server-side; guest carts keep them in localStorage. Both re-price
 * with the same bestValue day-count logic, so the total stays consistent.
 */
export async function setCartDates(startDate, endDate) {
  if (state.user) {
    try {
      state.cart = await cartApi.setDates(startDate, endDate);
      return { ok: true };
    } catch (err) { return fail(err); }
  }
  writeGuestDates(startDate, endDate);
  refreshGuestCart();
  return { ok: true };
}

/** Fold a guest cart into the server cart. Called right after sign-in. */
export async function mergeGuestCartIntoServer() {
  const items = readGuestCart();
  if (!items.length) {
    try { state.cart = await cartApi.get(); } catch { /* leave as-is */ }
    return;
  }
  try {
    state.cart = await cartApi.merge(items);
    clearGuestCart();
  } catch (err) {
    console.error('[DiaLux] cart merge failed:', err.message);
  }
}

/* ---------------- orders ---------------- */

export function isoDate(d = new Date()) {
  return d.toISOString().slice(0, 10);
}

export function addDays(dateStr, days) {
  const d = new Date(`${dateStr || isoDate()}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export async function placeOrder({ address, startDate, endDate } = {}) {
  if (!state.user) return { ok: false, error: 'Please sign in first' };
  try {
    const order = await ordersApi.create({ address, startDate, endDate });
    state.orders.unshift(order);
    state.cart = { ...EMPTY_CART };
    await loadProducts().catch(() => {});   // stock changed
    return { ok: true, order };
  } catch (err) { return fail(err); }
}

export async function refreshOrders() {
  if (!state.user) { state.orders = []; return state.orders; }
  try {
    const data = await ordersApi.mine();
    state.orders = data.orders || [];
  } catch { /* keep what we have */ }
  return state.orders;
}

/**
 * True when the signed-in user has an order for this product that has reached
 * a reviewable status. Used to decide whether to show the review form; the
 * POST endpoint enforces the same rule server-side.
 */
export function hasReviewableOrder(productId) {
  const pid = String(productId);
  return state.orders.some(o =>
    REVIEWABLE_STATUSES.includes(o.status) &&
    (o.items || []).some(i => String(i.product) === pid)
  );
}

function replaceOrder(order) {
  const i = state.orders.findIndex(o => o.id === order.id);
  if (i >= 0) state.orders[i] = order;
  else state.orders.unshift(order);
}

export async function cancelOrder(id) {
  try {
    replaceOrder(await ordersApi.cancel(id));
    await loadProducts().catch(() => {});
    return { ok: true };
  } catch (err) { return fail(err); }
}

export async function requestReturn(id) {
  try {
    replaceOrder(await ordersApi.requestReturn(id));
    return { ok: true };
  } catch (err) { return fail(err); }
}

export async function extendRental(id) {
  try {
    const { order, days } = await ordersApi.extend(id);
    replaceOrder(order);
    return { ok: true, days };
  } catch (err) { return fail(err); }
}

/** Simulated payment: confirms a pending order so it leaves "pending". */
export async function payOrder(id, method) {
  try {
    replaceOrder(await ordersApi.pay(id, method));
    return { ok: true };
  } catch (err) { return fail(err); }
}

/* ---------------- profile ---------------- */

export function currentProfile() {
  return state.user?.profile || null;
}

export async function saveProfile(patch) {
  if (!state.user) return { ok: false, error: 'Please sign in first' };
  try {
    const user = await usersApi.saveProfile(patch);
    state.user = { ...state.user, ...user };
    return { ok: true };
  } catch (err) { return fail(err); }
}
