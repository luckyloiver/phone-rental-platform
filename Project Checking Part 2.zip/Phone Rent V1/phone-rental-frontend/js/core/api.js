// ============================================================
// API client – handles all backend calls for DiaLux
// ============================================================

// The Express backend also serves this frontend, so in the normal setup
// (npm run dev → http://localhost:5000) the API sits on the same origin.
// Opening the page any other way — VS Code Live Server, file:// — falls
// back to talking to the dev server directly.
const SAME_ORIGIN = location.protocol.startsWith('http')
  && (location.port === '5000' || location.port === '');

const API_ROOT = SAME_ORIGIN ? '/api' : 'http://localhost:5000/api';

// ---- Custom API error ----
export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

// ---- Token management ----
export function getToken() {
  return localStorage.getItem('authToken');
}

export function setToken(token) {
  if (token) {
    localStorage.setItem('authToken', token);
  } else {
    localStorage.removeItem('authToken');
  }
}

/**
 * One place for every call: attaches the bearer token when we have one,
 * JSON-encodes the body, and turns any non-2xx response into an ApiError
 * carrying the server's own message.
 *
 * @param {string} path    path under /api, e.g. "/cart/items"
 * @param {object} [opts]  { method, body, query, fallback }
 */
async function request(path, { method = 'GET', body, query, fallback = 'Request failed' } = {}) {
  const url = new URL(`${API_ROOT}${path}`, location.origin);
  if (query) {
    Object.entries(query).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, v);
    });
  }

  const headers = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';

  let res;
  try {
    res = await fetch(url, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    // Network-level failure: server down, DNS, CORS preflight rejected.
    throw new ApiError('Cannot reach the DiaLux server', 0);
  }

  if (!res.ok) {
    const data = await res.json().catch(() => null);
    if (res.status === 401) setToken(null);
    throw new ApiError(data?.error || fallback, res.status);
  }

  if (res.status === 204) return null;
  return res.json().catch(() => null);
}

// ---- Auth ----
export const authApi = {
  login: (email, password) =>
    request('/auth/login', {
      method: 'POST',
      body: { email, password },
      fallback: 'Login failed',
    }),

  register: (name, email, password) =>
    request('/auth/register', {
      method: 'POST',
      body: { name, email, password },
      fallback: 'Registration failed',
    }),

  /** Exchange a Google ID token (the GSI "credential") for our own JWT. */
  googleLogin: (credential) =>
    request('/auth/google', {
      method: 'POST',
      body: { token: credential },
      fallback: 'Google sign-in failed',
    }),

  /** Validate the stored token and return the current user. */
  me: async () => {
    if (!getToken()) throw new ApiError('No token found', 401);
    try {
      return await request('/auth/me', { fallback: 'Failed to fetch user' });
    } catch (err) {
      // request() already dropped the dead token; normalise the message.
      if (err instanceof ApiError && err.status === 401) {
        throw new ApiError('Session expired', 401);
      }
      throw err;
    }
  },
};

// ---- Products ----
export const productsApi = {
  /** @param {object} [params] cat, brand, grade, q, maxWeekly, sort */
  list: (params) =>
    request('/products', { query: params, fallback: 'Could not load the catalog' }),

  // Admin writes
  create: (payload) =>
    request('/products', { method: 'POST', body: payload, fallback: 'Could not create the device' }),

  update: (id, payload) =>
    request(`/products/${id}`, { method: 'PUT', body: payload, fallback: 'Could not save the device' }),

  remove: (id) =>
    request(`/products/${id}`, { method: 'DELETE', fallback: 'Could not delete the device' }),

  /** Relative stock change: +1 / -1. */
  adjustStock: (id, delta) =>
    request(`/products/${id}/stock`, {
      method: 'PATCH',
      body: { delta },
      fallback: 'Could not adjust stock',
    }),
};

// ---- Reviews (verified renters only, one per user per product) ----
export const reviewsApi = {
  list: (productId) =>
    request(`/products/${productId}/reviews`, { fallback: 'Could not load reviews' }),

  create: (productId, { rating, comment }) =>
    request(`/products/${productId}/reviews`, {
      method: 'POST',
      body: { rating, comment },
      fallback: 'Could not submit your review',
    }),
};

// ---- Cart (all authenticated; every call returns the priced cart) ----
export const cartApi = {
  get: () => request('/cart', { fallback: 'Could not load your cart' }),

  addItem: (productId, plan, qty) =>
    request('/cart/items', {
      method: 'POST',
      body: { productId, plan, qty },
      fallback: 'Could not add to cart',
    }),

  /** @param {object} patch { newPlan?, qty? } */
  updateItem: (productId, plan, patch) =>
    request('/cart/items', {
      method: 'PATCH',
      body: { productId, plan, ...patch },
      fallback: 'Could not update the cart',
    }),

  removeItem: (productId, plan) =>
    request('/cart/items', {
      method: 'DELETE',
      body: { productId, plan },
      fallback: 'Could not remove the item',
    }),

  clear: () => request('/cart', { method: 'DELETE', fallback: 'Could not empty the cart' }),

  /** Set the rental window that prices the whole cart. */
  setDates: (startDate, endDate) =>
    request('/cart', {
      method: 'PATCH',
      body: { startDate, endDate },
      fallback: 'Could not update your rental dates',
    }),

  /** Fold a guest cart into the server cart after sign-in. */
  merge: (items) =>
    request('/cart/merge', { method: 'POST', body: { items }, fallback: 'Could not merge your cart' }),
};

// ---- Orders ----
export const ordersApi = {
  create: ({ address, startDate, endDate } = {}) =>
    request('/orders', {
      method: 'POST',
      body: { address, startDate, endDate },
      fallback: 'Checkout failed',
    }),

  mine: () => request('/orders/mine', { fallback: 'Could not load your orders' }),

  cancel: (id) =>
    request(`/orders/${id}/cancel`, { method: 'POST', fallback: 'Could not cancel the booking' }),

  /** Simulated payment — confirms a pending order. */
  pay: (id, method) =>
    request(`/orders/${id}/pay`, {
      method: 'POST',
      body: { method },
      fallback: 'Payment could not be processed',
    }),

  requestReturn: (id) =>
    request(`/orders/${id}/return`, { method: 'POST', fallback: 'Could not request a return' }),

  /** @returns {{ order: object, days: number }} */
  extend: (id) =>
    request(`/orders/${id}/extend`, { method: 'POST', fallback: 'Could not extend the rental' }),

  // Admin
  all: (status) =>
    request('/orders', { query: { status }, fallback: 'Could not load orders' }),

  setStatus: (id, status) =>
    request(`/orders/${id}/status`, {
      method: 'PATCH',
      body: { status },
      fallback: 'Could not update the order status',
    }),

  reports: () =>
    request('/orders/reports/summary', { fallback: 'Could not load the report' }),
};

// ---- Users ----
export const usersApi = {
  /** @param {object} patch { phone?, address?, city?, zip? } */
  saveProfile: (patch) =>
    request('/users/me/profile', {
      method: 'PATCH',
      body: patch,
      fallback: 'Could not save your details',
    }),
};
