// ============================================================
// DiaLux — pages/admin.js
// Product CRUD, order management, inventory and reports.
//
// Every write here goes through an admin-guarded endpoint, so the
// server is the real gate. Hiding the UI from non-admins is just
// courtesy — a non-admin who forces their way in gets 403s.
// ============================================================

import * as fx from '../3d-enhancements.js';
import { bootPage, refreshFx } from '../core/page.js';
import { state, loadProducts, productById, ORDER_STATUSES, CATEGORIES, GRADES } from '../core/state.js';
import { productsApi, ordersApi } from '../core/api.js';
import {
  peso, escapeHtml, formatDate, toast, statusClass, titleCase, catLabel,
  categoryIcon, gradeClass, emptyState,
} from '../core/ui.js';
import { isAdmin } from '../core/auth.js';

const TABS = [
  { key: 'products',  label: 'Products' },
  { key: 'orders',    label: 'Orders' },
  { key: 'inventory', label: 'Inventory' },
  { key: 'reports',   label: 'Reports' },
];

let activeTab = 'products';
let editingId = null;
let allOrders = [];
let reportPeriod = 'month';   // Reports revenue-over-time granularity: week | month | year

const PRODUCT_CATS = CATEGORIES.filter(c => c.key !== 'all');
const shortId = (id) => String(id).slice(-6).toUpperCase();

/* ---------------- shell ---------------- */

function renderShell() {
  const wrap = document.getElementById('adminDashWrap');
  if (!wrap) return;

  if (!state.user) {
    wrap.innerHTML = emptyState(
      'Admin access required',
      'Sign in with an administrator account to manage the platform.',
      '<a class="btn btn-primary" href="/index.html#auth">Sign in</a>'
    );
    return;
  }

  if (!isAdmin()) {
    // Deliberately vague: a customer who lands here by typing the URL
    // shouldn't be handed instructions for escalating their own role.
    wrap.innerHTML = emptyState(
      'This page isn’t available',
      'Your account doesn’t have access to the management dashboard.',
      '<a class="btn btn-primary" href="/products.html">Back to catalog</a>'
    );
    return;
  }

  wrap.innerHTML = `
    <div class="admin-shell">
      <nav class="admin-side" id="adminTabs">
        ${TABS.map(t => `
          <button type="button" data-tab="${t.key}"${t.key === activeTab ? ' class="active"' : ''}>${t.label}</button>
        `).join('')}
      </nav>
      <div class="admin-card" id="adminPanel"></div>
    </div>`;

  wrap.querySelector('#adminTabs').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-tab]');
    if (!btn) return;
    activeTab = btn.dataset.tab;
    editingId = null;
    wrap.querySelectorAll('#adminTabs button').forEach(b => b.classList.toggle('active', b === btn));
    renderPanel();
  });

  return renderPanel();
}

function loading(panel, label = 'Loading…') {
  panel.innerHTML = `<p style="color:var(--ink-muted);font-size:.9rem;padding:8px 0;">${label}</p>`;
}

async function renderPanel() {
  const panel = document.getElementById('adminPanel');
  if (!panel) return;

  try {
    if (activeTab === 'products')  await renderProducts(panel);
    if (activeTab === 'orders')    await renderOrders(panel);
    if (activeTab === 'inventory') await renderInventory(panel);
    if (activeTab === 'reports')   await renderReports(panel);
  } catch (err) {
    panel.innerHTML = `<p style="color:var(--danger);font-size:.9rem;">${escapeHtml(err.message)}</p>`;
    return;
  }

  refreshFx();
}

/* ---------------- products ---------------- */

/** Product.specs (a plain object) → "Key: Value" lines for the textarea. */
function specsToText(specs) {
  return Object.entries(specs || {}).map(([k, v]) => `${k}: ${v}`).join('\n');
}

/** "Key: Value" lines → a plain object. Blank and colon-less lines are skipped. */
function parseSpecs(text) {
  const out = {};
  String(text || '').split('\n').forEach(line => {
    const i = line.indexOf(':');
    if (i < 0) return;
    const key = line.slice(0, i).trim();
    const val = line.slice(i + 1).trim();
    if (key && val) out[key] = val;
  });
  return out;
}

/** Newline- or comma-separated text → a trimmed array of non-empty strings. */
function parseIncluded(text) {
  return String(text || '').split(/[\n,]/).map(s => s.trim()).filter(Boolean);
}

function productFormMarkup() {
  const p = editingId ? productById(editingId) : null;
  const v = (key, fallback = '') => escapeHtml(String(p?.[key] ?? fallback));

  return `
  <form class="pf-form" id="productForm">
    <h4 style="margin-bottom:14px;">${p ? `Edit “${escapeHtml(p.name)}”` : 'Add a new device'}</h4>

    <div class="pf-grid">
      <input class="mini-select" name="name" placeholder="Device name" value="${v('name')}" required>
      <input class="mini-select" name="brand" placeholder="Brand" value="${v('brand')}" required>
      <select class="mini-select" name="cat">
        ${PRODUCT_CATS.map(c => `<option value="${c.key}"${p?.cat === c.key ? ' selected' : ''}>${escapeHtml(c.label)}</option>`).join('')}
      </select>
    </div>

    <div class="pf-grid">
      <select class="mini-select" name="grade">
        ${GRADES.map(g => `<option value="${g}"${p?.grade === g ? ' selected' : ''}>${g}</option>`).join('')}
      </select>
      <input class="mini-select" name="stock" type="number" min="0" placeholder="Stock" value="${v('stock', 1)}" required>
      <input class="mini-select" name="deposit" type="number" min="0" placeholder="Deposit ₱" value="${v('deposit', 0)}" required>
    </div>

    <div class="pf-grid">
      <input class="mini-select" name="daily" type="number" min="0" placeholder="Daily ₱" value="${v('daily', 0)}" required>
      <input class="mini-select" name="weekly" type="number" min="0" placeholder="Weekly ₱" value="${v('weekly', 0)}" required>
      <input class="mini-select" name="monthly" type="number" min="0" placeholder="Monthly ₱" value="${v('monthly', 0)}" required>
    </div>

    <div class="pf-grid wide">
      <textarea class="mini-select" name="desc" rows="2" placeholder="Short description">${v('desc')}</textarea>
    </div>

    <div class="pf-grid wide">
      <input class="mini-select" name="image" type="url" placeholder="Image URL — https://… (blank uses the category icon)" value="${v('image')}">
    </div>

    <div class="pf-grid wide">
      <textarea class="mini-select" name="specs" rows="4" placeholder="Specifications — one “Key: Value” per line&#10;Display: 6.1-inch OLED&#10;Chip: A16 Bionic&#10;Storage: 128GB">${escapeHtml(specsToText(p?.specs))}</textarea>
    </div>

    <div class="pf-grid wide">
      <textarea class="mini-select" name="included" rows="3" placeholder="What's included — one per line&#10;Original charger&#10;USB-C cable&#10;Protective case">${escapeHtml((p?.included || []).join('\n'))}</textarea>
    </div>

    <div style="display:flex;gap:8px;flex-wrap:wrap;">
      <button class="btn btn-primary btn-sm" type="submit">${p ? 'Save changes' : 'Add device'}</button>
      ${p ? '<button class="btn btn-ghost btn-sm" type="button" id="cancelEdit">Cancel</button>' : ''}
    </div>
  </form>`;
}

async function renderProducts(panel) {
  panel.innerHTML = `
    <div class="admin-top">
      <h3>Products</h3>
      <span style="font-size:.8rem;color:var(--ink-faint);">${state.products.length} in catalog</span>
    </div>

    ${productFormMarkup()}

    <div class="table-wrap">
      <table>
        <thead>
          <tr><th>Device</th><th>Category</th><th>Grade</th><th>Weekly</th><th>Deposit</th><th>Stock</th><th>Actions</th></tr>
        </thead>
        <tbody>
          ${state.products.map(p => `
            <tr>
              <td>
                <span class="mini-thumb">${categoryIcon(p.cat)}</span>
                ${escapeHtml(p.name)}
                <div style="font-size:.72rem;color:var(--ink-faint);">${escapeHtml(p.brand)}</div>
              </td>
              <td>${escapeHtml(catLabel(p.cat))}</td>
              <td><span class="grade-tag ${gradeClass(p.grade)}">${escapeHtml(p.grade)}</span></td>
              <td>${peso(p.weekly)}</td>
              <td>${peso(p.deposit)}</td>
              <td>${p.stock}</td>
              <td>
                <div class="row-actions">
                  <button type="button" data-act="edit" data-id="${p.id}">Edit</button>
                  <button type="button" class="del" data-act="delete" data-id="${p.id}">Delete</button>
                </div>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;

  panel.querySelector('#productForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const num = (k) => Number(fd.get(k)) || 0;

    const payload = {
      name: String(fd.get('name')).trim(),
      brand: String(fd.get('brand')).trim(),
      cat: String(fd.get('cat')),
      grade: String(fd.get('grade')),
      stock: num('stock'),
      deposit: num('deposit'),
      daily: num('daily'),
      weekly: num('weekly'),
      monthly: num('monthly'),
      desc: String(fd.get('desc')).trim(),
      image: String(fd.get('image') || '').trim(),
      specs: parseSpecs(fd.get('specs')),
      included: parseIncluded(fd.get('included')),
    };

    if (!payload.name || !payload.brand) { toast('Name and brand are required', 'error'); return; }

    const btn = e.target.querySelector('button[type="submit"]');
    const done = fx.setBtnLoading(btn, 'Saving…');
    try {
      if (editingId) {
        await productsApi.update(editingId, payload);
        toast(`${payload.name} updated`);
        editingId = null;
      } else {
        await productsApi.create(payload);
        toast(`${payload.name} added`);
      }
      await loadProducts();
      await renderPanel();
    } catch (err) {
      done();
      toast(err.message, 'error');
    }
  });

  panel.querySelector('#cancelEdit')?.addEventListener('click', () => {
    editingId = null;
    renderPanel();
  });

  panel.querySelector('tbody')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    const id = btn.dataset.id;

    if (btn.dataset.act === 'edit') {
      editingId = id;
      await renderPanel();
      document.getElementById('productForm')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    if (btn.dataset.act === 'delete') {
      const p = productById(id);
      if (!p) return;
      if (!confirm(`Remove “${p.name}” from the catalog?\n\nExisting orders keep their history.`)) return;

      const done = fx.setBtnLoading(btn, '…');
      try {
        await productsApi.remove(id);
        toast(`${p.name} removed`);
        if (editingId === id) editingId = null;
        await loadProducts();
        await renderPanel();
      } catch (err) {
        done();
        toast(err.message, 'error');
      }
    }
  });
}

/* ---------------- orders ---------------- */

async function renderOrders(panel) {
  loading(panel, 'Loading orders…');
  const data = await ordersApi.all();
  allOrders = data.orders || [];

  if (!allOrders.length) {
    panel.innerHTML = `
      <div class="admin-top"><h3>Orders</h3></div>
      <p style="color:var(--ink-muted);font-size:.9rem;">No bookings yet. Confirm one from the cart to see it here.</p>`;
    return;
  }

  panel.innerHTML = `
    <div class="admin-top">
      <h3>Orders</h3>
      <span style="font-size:.8rem;color:var(--ink-faint);">${allOrders.length} total</span>
    </div>

    <div class="table-wrap">
      <table>
        <thead>
          <tr><th>#</th><th>Customer</th><th>Devices</th><th>Dates</th><th>Total</th><th>Status</th></tr>
        </thead>
        <tbody>
          ${allOrders.map(o => `
            <tr>
              <td><b>${shortId(o.id)}</b></td>
              <td>
                ${escapeHtml(o.userName || '—')}
                <div style="font-size:.72rem;color:var(--ink-faint);">${escapeHtml(o.userEmail)}</div>
              </td>
              <td>${o.items.map(i => `${i.qty} × ${escapeHtml(i.name)}`).join('<br>')}</td>
              <td>
                ${formatDate(o.startDate)}
                <div style="font-size:.72rem;color:var(--ink-faint);">to ${formatDate(o.endDate)}</div>
              </td>
              <td>${peso(o.total)}</td>
              <td>
                <span class="status-pill ${statusClass(o.status)}" style="margin-bottom:6px;display:inline-block;">${escapeHtml(titleCase(o.status))}</span>
                <select class="mini-select" data-order="${o.id}" style="width:100%;">
                  ${ORDER_STATUSES.map(s => `<option value="${s}"${s === o.status ? ' selected' : ''}>${escapeHtml(titleCase(s))}</option>`).join('')}
                </select>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;

  panel.querySelector('tbody').addEventListener('change', async (e) => {
    const select = e.target.closest('[data-order]');
    if (!select) return;
    select.disabled = true;
    try {
      await ordersApi.setStatus(select.dataset.order, select.value);
      toast(`Booking #${shortId(select.dataset.order)} → ${titleCase(select.value)}`);
      // Closing an order returns its units to the catalog.
      await loadProducts();
      await renderPanel();
    } catch (err) {
      select.disabled = false;
      toast(err.message, 'error');
    }
  });
}

/* ---------------- inventory ---------------- */

async function renderInventory(panel) {
  loading(panel, 'Loading inventory…');
  const rep = await ordersApi.reports();

  // Units currently with customers, per product.
  const data = await ordersApi.all();
  const rented = {};
  (data.orders || [])
    .filter(o => !['cancelled', 'completed', 'refunded'].includes(o.status))
    .forEach(o => o.items.forEach(i => {
      rented[i.product] = (rented[i.product] || 0) + i.qty;
    }));

  panel.innerHTML = `
    <div class="admin-top"><h3>Inventory</h3></div>

    <div class="stat-grid">
      <div class="stat-card"><span>Units on shelf</span><b>${rep.unitsOnShelf}</b></div>
      <div class="stat-card"><span>Units rented out</span><b>${rep.unitsRentedOut}</b></div>
      <div class="stat-card"><span>Low stock</span><b>${rep.lowStock}</b></div>
      <div class="stat-card"><span>Out of stock</span><b>${rep.outOfStock}</b></div>
    </div>

    <div class="table-wrap">
      <table>
        <thead>
          <tr><th>Device</th><th>On shelf</th><th>Rented out</th><th>Status</th><th>Adjust</th></tr>
        </thead>
        <tbody>
          ${state.products.map(p => {
            const status = p.stock === 0
              ? '<span class="wipe-pending">Out of stock</span>'
              : p.stock <= 2 ? '<span class="wipe-pending">Low</span>' : '<span class="wipe-ok">Healthy</span>';
            return `
            <tr>
              <td><span class="mini-thumb">${categoryIcon(p.cat)}</span>${escapeHtml(p.name)}</td>
              <td><b>${p.stock}</b></td>
              <td>${rented[p.id] || 0}</td>
              <td>${status}</td>
              <td>
                <div class="row-actions">
                  <button type="button" data-delta="-1" data-id="${p.id}" ${p.stock === 0 ? 'disabled' : ''}>−1</button>
                  <button type="button" data-delta="1" data-id="${p.id}">+1</button>
                </div>
              </td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`;

  panel.querySelector('tbody').addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-delta]');
    if (!btn) return;
    btn.disabled = true;
    try {
      await productsApi.adjustStock(btn.dataset.id, Number(btn.dataset.delta));
      await loadProducts();
      await renderPanel();
    } catch (err) {
      btn.disabled = false;
      toast(err.message, 'error');
    }
  });
}

/* ---------------- reports ---------------- */

function barChart(rows, format = peso) {
  if (!rows.length) return '<p style="font-size:.82rem;color:var(--ink-muted);">Not enough data yet.</p>';
  const max = Math.max(...rows.map(r => r.value)) || 1;
  return `
    <div class="bar-chart">
      ${rows.map(r => `
        <div class="chart-row">
          <label title="${escapeHtml(r.label)}">${escapeHtml(r.label)}</label>
          <div class="chart-track"><div class="chart-fill" style="width:${Math.round((r.value / max) * 100)}%;"></div></div>
          <span class="chart-value">${format(r.value)}</span>
        </div>`).join('')}
    </div>`;
}

const toRows = (obj, labeller = (k) => k) => Object.entries(obj || {})
  .map(([k, value]) => ({ label: labeller(k), value }))
  .sort((a, b) => b.value - a.value);

const MONTH_ABBR = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** The revenue-over-time bucket that a period name maps to. */
function periodSource(rep, period = reportPeriod) {
  if (period === 'week') return rep.byWeek;
  if (period === 'year') return rep.byYear;
  return rep.byMonth;
}

/** Friendly label for a bucket key: "2026-09" → "Sep 2026", "2026-W36" → "2026 W36". */
function periodLabel(period, key) {
  if (period === 'month') {
    const [y, m] = String(key).split('-');
    return `${MONTH_ABBR[Number(m) - 1] || m} ${y}`;
  }
  if (period === 'week') return String(key).replace('-W', ' W');
  return String(key);
}

/**
 * A bucket object → chart rows in chronological order. The ISO-8601 keys
 * ("2026-W03", "2026-09") are zero-padded, so a plain string sort is already
 * chronological; we keep the twelve most recent so the chart stays readable.
 */
const toTimeRows = (obj, period) => Object.entries(obj || {})
  .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
  .slice(-12)
  .map(([k, value]) => ({ label: periodLabel(period, k), value }));

async function renderReports(panel) {
  loading(panel, 'Building reports…');
  const rep = await ordersApi.reports();

  panel.innerHTML = `
    <div class="admin-top"><h3>Reports</h3></div>

    <div class="stat-grid">
      <div class="stat-card"><span>Rental revenue</span><b>${peso(rep.revenue)}</b></div>
      <div class="stat-card"><span>Bookings</span><b>${rep.orderCount}</b></div>
      <div class="stat-card"><span>Active rentals</span><b>${rep.activeRentals}</b></div>
      <div class="stat-card"><span>Deposits held</span><b>${peso(rep.depositsHeld)}</b></div>
    </div>

    <div class="report-panel" style="margin-bottom:18px;">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:16px;">
        <h4 style="margin:0;">Revenue over time</h4>
        <div class="period-toggle" id="periodToggle">
          ${['week', 'month', 'year'].map(pd => `
            <button type="button" data-period="${pd}"${pd === reportPeriod ? ' class="active"' : ''}>${titleCase(pd)}</button>
          `).join('')}
        </div>
      </div>
      <div id="periodChart">${barChart(toTimeRows(periodSource(rep), reportPeriod))}</div>
    </div>

    <div class="report-grid">
      <div class="report-panel">
        <h4>Top devices by revenue</h4>
        ${barChart(toRows(rep.byDevice).slice(0, 6))}
      </div>
      <div class="report-panel">
        <h4>Revenue by category</h4>
        ${barChart(toRows(rep.byCategory, catLabel))}
      </div>
      <div class="report-panel">
        <h4>Bookings by status</h4>
        ${barChart(toRows(rep.byStatus, titleCase), n => String(n))}
      </div>
      <div class="report-panel">
        <h4>Catalog by condition</h4>
        ${barChart(toRows(rep.byGrade), n => `${n} device${n === 1 ? '' : 's'}`)}
      </div>
    </div>`;

  // Swap just the time-series chart when the granularity changes — the report
  // payload already carries all three buckets, so there's nothing to refetch.
  panel.querySelector('#periodToggle').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-period]');
    if (!btn) return;
    reportPeriod = btn.dataset.period;
    panel.querySelectorAll('#periodToggle button').forEach(b => b.classList.toggle('active', b === btn));
    panel.querySelector('#periodChart').innerHTML = barChart(toTimeRows(periodSource(rep), reportPeriod));
  });
}

bootPage('admin', renderShell);
