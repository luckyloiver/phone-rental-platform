// ============================================================
// DiaLux — pages/profile.js
// Account details, saved address, and rental history.
// ============================================================

import * as fx from '../3d-enhancements.js';
import { bootPage, refreshFx } from '../core/page.js';
import {
  state, currentProfile, saveProfile, cancelOrder, requestReturn,
  extendRental, payOrder, refreshOrders, STAGE_LABELS, STATUS_STAGE,
  REVIEWABLE_STATUSES,
} from '../core/state.js';
import {
  peso, escapeHtml, formatDate, toast, emptyState, statusClass, titleCase, catLabel,
} from '../core/ui.js';
import { requireAuth } from '../core/auth.js';

const shortId = (id) => String(id).slice(-6).toUpperCase();

/* ---------------- account ---------------- */

function renderAccount() {
  const box = document.getElementById('accountContent');
  if (!box) return;

  // The sign-in prompt is a single centred block, so drop the 2-column
  // grid while it's showing.
  box.classList.toggle('account-grid', Boolean(state.user));
  if (!requireAuth(box, 'Sign in to manage your profile and see your rentals.')) return;

  const profile = currentProfile() || {};
  const u = state.user;

  box.innerHTML = `
    <div class="account-card">
      <h3>Personal details</h3>
      <p>These come from your DiaLux account.</p>
      <div class="field">
        <label>Full name</label>
        <input type="text" value="${escapeHtml(u.name || '')}" readonly>
      </div>
      <div class="field">
        <label>Email</label>
        <input type="email" value="${escapeHtml(u.email || '')}" readonly>
      </div>
      <div class="field">
        <label>Account type</label>
        <input type="text" value="${escapeHtml(titleCase(u.role || 'user'))}" readonly>
      </div>
    </div>

    <div class="account-card">
      <h3>Delivery address</h3>
      <p>Where we send your device. Required before checkout.</p>
      <form id="addressForm">
        <div class="field">
          <label for="pf-phone">Mobile number</label>
          <input type="tel" id="pf-phone" value="${escapeHtml(profile.phone || '')}" placeholder="09XX XXX XXXX">
        </div>
        <div class="field">
          <label for="pf-address">Street address</label>
          <input type="text" id="pf-address" value="${escapeHtml(profile.address || '')}" placeholder="Unit / house no., street, barangay" required>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="pf-city">City</label>
            <input type="text" id="pf-city" value="${escapeHtml(profile.city || '')}" placeholder="Quezon City">
          </div>
          <div class="field">
            <label for="pf-zip">ZIP</label>
            <input type="text" id="pf-zip" value="${escapeHtml(profile.zip || '')}" placeholder="1100">
          </div>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">Save address</button>
      </form>
    </div>`;

  box.querySelector('#addressForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const address = document.getElementById('pf-address').value.trim();
    if (!address) { toast('Street address is required', 'error'); return; }

    const btn = e.target.querySelector('button[type="submit"]');
    const done = fx.setBtnLoading(btn, 'Saving…');
    const res = await saveProfile({
      phone: document.getElementById('pf-phone').value.trim(),
      address,
      city: document.getElementById('pf-city').value.trim(),
      zip: document.getElementById('pf-zip').value.trim(),
    });
    done();
    toast(res.ok ? 'Address saved' : res.error, res.ok ? 'ok' : 'error');
  });
}

/* ---------------- orders ---------------- */

function timelineMarkup(status) {
  const stage = STATUS_STAGE[status] ?? 0;
  const cancelled = status === 'cancelled';
  return `
    <div class="order-timeline">
      ${STAGE_LABELS.map((label, i) => `
        <div class="timeline-step${!cancelled && i <= stage ? ' done' : ''}">${label}</div>
      `).join('')}
    </div>`;
}

function orderActions(o) {
  const buttons = [];
  if (o.status === 'pending' && !o.paid) {
    buttons.push(`<button class="btn btn-primary btn-sm" data-act="pay" data-id="${o.id}">Pay now</button>`);
    buttons.push(`<button class="btn btn-ghost btn-sm" data-act="cancel" data-id="${o.id}">Cancel booking</button>`);
  } else if (o.status === 'pending') {
    buttons.push(`<button class="btn btn-ghost btn-sm" data-act="cancel" data-id="${o.id}">Cancel booking</button>`);
  }
  if (o.status === 'delivered' || o.status === 'active') {
    buttons.push(`<button class="btn btn-primary btn-sm" data-act="return" data-id="${o.id}">Request return</button>`);
    buttons.push(`<button class="btn btn-ghost btn-sm" data-act="extend" data-id="${o.id}">Extend rental</button>`);
  }
  if (o.status === 'return-requested') {
    buttons.push('<span class="summary-note">Return requested — our technician will confirm pickup.</span>');
  }
  return buttons.length ? `<div class="order-actions">${buttons.join('')}</div>` : '';
}

function orderCard(o) {
  const reviewable = REVIEWABLE_STATUSES.includes(o.status);
  const paidBadge = o.paid
    ? `<span style="font-size:.72rem;font-weight:700;font-family:'IBM Plex Mono';color:#0F7A5F;background:var(--signal-soft);padding:5px 10px;border-radius:99px;">✓ Paid</span>`
    : '';

  return `
  <div class="order-card">
    <div class="order-top">
      <b>Booking #${shortId(o.id)}</b>
      <span style="display:inline-flex;align-items:center;gap:8px;">
        ${paidBadge}
        <span class="status-pill ${statusClass(o.status)}">${escapeHtml(titleCase(o.status))}</span>
      </span>
    </div>

    <div class="order-items">
      ${o.items.map(i => `
        <div>${i.qty} × ${escapeHtml(i.name)}
          <span style="color:var(--ink-faint);">(${escapeHtml(catLabel(i.cat))} · ${peso(i.rate)} each)</span>
          ${reviewable && i.product ? `<a class="review-link" href="/products.html#device-${escapeHtml(String(i.product))}">Leave a review ›</a>` : ''}
        </div>`).join('')}
    </div>

    <div class="order-meta-grid">
      <div class="order-meta">Ordered<b>${formatDate(o.createdAt)}</b></div>
      <div class="order-meta">Starts<b>${formatDate(o.startDate)}</b></div>
      <div class="order-meta">Due back<b>${formatDate(o.endDate)}</b></div>
      <div class="order-meta">${o.paid ? 'Total paid' : 'Total due'}<b>${peso(o.total)}</b></div>
    </div>

    ${timelineMarkup(o.status)}

    <div class="order-foot">
      <span>Deposit held: <b class="refundable">${peso(o.deposit)}</b></span>
      <span>Delivering to: ${escapeHtml(o.address || '—')}</span>
    </div>

    ${orderActions(o)}
  </div>`;
}

function renderOrders() {
  const list = document.getElementById('ordersList');
  if (!list) return;
  if (!state.user) { list.innerHTML = ''; return; }

  if (!state.orders.length) {
    list.innerHTML = emptyState(
      'No rentals yet',
      'Once you confirm a booking it will show up here with live status tracking.',
      '<a class="btn btn-primary" href="/products.html">Browse devices</a>'
    );
    return;
  }

  list.innerHTML = state.orders.map(orderCard).join('');
  bindOrderActions(list);
  refreshFx();
}

/* Delegated once onto the stable #ordersList element — renderOrders()
   replaces its innerHTML, not the node, so the binding survives. */
function bindOrderActions(list) {
  if (list.dataset.actionsBound) return;
  list.dataset.actionsBound = '1';

  list.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    const id = btn.dataset.id;
    const act = btn.dataset.act;

    if (act === 'cancel' && !confirm('Cancel this booking?')) return;

    const done = fx.setBtnLoading(btn, 'Working…');
    let res;
    if (act === 'pay') {
      res = await payOrder(id, 'gcash');
      if (res.ok) toast(`Payment confirmed for #${shortId(id)}`);
    } else if (act === 'cancel') {
      res = await cancelOrder(id);
      if (res.ok) toast(`Booking #${shortId(id)} cancelled`);
    } else if (act === 'return') {
      res = await requestReturn(id);
      if (res.ok) toast(`Return requested for #${shortId(id)}`);
    } else if (act === 'extend') {
      res = await extendRental(id);
      if (res.ok) toast(`Extended by ${res.days} day${res.days === 1 ? '' : 's'}`);
    }

    done();
    if (res && !res.ok) toast(res.error, 'error');
    await refreshOrders();
    renderOrders();
  });
}

bootPage('profile', () => {
  renderAccount();
  renderOrders();
  if (location.hash === '#orders') {
    document.getElementById('ordersList')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
});
