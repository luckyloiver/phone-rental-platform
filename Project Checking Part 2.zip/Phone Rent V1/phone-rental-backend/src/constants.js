// ============================================================
// DiaLux — shared domain constants
// Kept in one place so routes, models and validation agree.
// ============================================================

const CATEGORIES = ['phone', 'tablet', 'laptop', 'wifi'];

const GRADES = ['Like New', 'Good', 'Fair'];

const PLANS = ['Daily', 'Weekly', 'Monthly'];

const PLAN_KEY = { Daily: 'daily', Weekly: 'weekly', Monthly: 'monthly' };

const PLAN_DAYS = { Daily: 1, Weekly: 7, Monthly: 30 };

// Every status an order can hold. The customer-visible timeline uses
// the first six; the rest are operational states an admin can set.
const ORDER_STATUSES = [
  'pending',
  'payment-confirmed',
  'approved',
  'preparing',
  'shipped',
  'delivered',
  'active',
  'return-requested',
  'inspection',
  'refunded',
  'completed',
  'cancelled',
];

// Statuses in which the units are considered still out with a customer,
// so stock stays decremented.
const OPEN_STATUSES = ORDER_STATUSES.filter(
  s => !['cancelled', 'completed', 'refunded'].includes(s)
);

// Statuses in which a customer has actually received the device, so they
// are allowed to review it. Anything before "delivered" hasn't shipped.
const QUALIFYING_REVIEW_STATUSES = [
  'delivered', 'active', 'return-requested', 'inspection', 'completed',
];

// Simulated payment methods offered at checkout. No real gateway.
const PAYMENT_METHODS = ['gcash', 'card', 'cash'];

// Flat delivery fee, in pesos.
const DELIVERY_FEE = 150;

/**
 * Whole calendar days between two YYYY-MM-DD dates, minimum 1.
 * Sep 1 → Sep 8 = 7; the same day (or an invalid pair) = 1.
 */
function daysBetween(startDate, endDate) {
  const a = Date.parse(`${startDate}T00:00:00Z`);
  const b = Date.parse(`${endDate}T00:00:00Z`);
  if (Number.isNaN(a) || Number.isNaN(b)) return 1;
  return Math.max(1, Math.round((b - a) / 86400000));
}

/**
 * Cheapest rent for `days` using any mix of the daily/weekly/monthly tiers,
 * overshoot allowed (7 days on a weekly rate beats 7 daily charges). A tiny
 * unbounded-knapsack DP; tiers priced at 0 are treated as unavailable.
 *
 * MUST stay identical to bestValue() in the frontend's core/state.js so the
 * price shown in the cart equals the price charged at checkout.
 */
function bestValue(product, days) {
  const n = Math.max(1, Math.ceil(Number(days) || 1));
  const tiers = [
    [1, Number(product.daily) || 0],
    [7, Number(product.weekly) || 0],
    [30, Number(product.monthly) || 0],
  ].filter(t => t[1] > 0);
  if (!tiers.length) return 0;

  const dp = new Array(n + 1).fill(Infinity);
  dp[0] = 0;
  for (let i = 1; i <= n; i++) {
    for (const [len, rate] of tiers) {
      dp[i] = Math.min(dp[i], dp[Math.max(0, i - len)] + rate);
    }
  }
  return dp[n];
}

module.exports = {
  CATEGORIES, GRADES, PLANS, PLAN_KEY, PLAN_DAYS,
  ORDER_STATUSES, OPEN_STATUSES, QUALIFYING_REVIEW_STATUSES,
  PAYMENT_METHODS, DELIVERY_FEE, daysBetween, bestValue,
};
