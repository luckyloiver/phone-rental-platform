const express = require('express');
const mongoose = require('mongoose');
const User = require('../models/User');
const auth = require('../middlewares/auth');
const admin = require('../middlewares/admin');

const router = express.Router();
router.use(auth);

const isValidId = (id) => mongoose.Types.ObjectId.isValid(id);

/** Save the signed-in user's delivery details. */
router.patch('/me/profile', async (req, res, next) => {
  try {
    const { phone, address, city, zip } = req.body;

    const patch = {};
    if (phone   !== undefined) patch['profile.phone']   = String(phone).trim();
    if (address !== undefined) patch['profile.address'] = String(address).trim();
    if (city    !== undefined) patch['profile.city']    = String(city).trim();
    if (zip     !== undefined) patch['profile.zip']     = String(zip).trim();

    if (!Object.keys(patch).length) {
      return res.status(400).json({ error: 'Nothing to update' });
    }

    const user = await User.findByIdAndUpdate(
      req.userId,
      { $set: patch },
      { returnDocument: 'after', runValidators: true }
    );
    if (!user) return res.status(401).json({ error: 'Account no longer exists' });

    res.json(user);
  } catch (err) { next(err); }
});

/* ---------------- admin ---------------- */

router.get('/', auth, admin, async (req, res, next) => {
  try {
    const users = await User.find({}).sort({ createdAt: -1 });
    res.json({ users, count: users.length });
  } catch (err) { next(err); }
});

router.patch('/:id/role', auth, admin, async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) return res.status(400).json({ error: 'Invalid user id' });

    const { role } = req.body;
    if (!['user', 'admin'].includes(role)) {
      return res.status(400).json({ error: 'role must be "user" or "admin"' });
    }

    // Don't let the last admin demote themselves into a locked-out system.
    if (role === 'user' && String(req.params.id) === String(req.userId)) {
      const admins = await User.countDocuments({ role: 'admin' });
      if (admins <= 1) {
        return res.status(409).json({ error: 'You are the only administrator — promote someone else first' });
      }
    }

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { $set: { role } },
      { returnDocument: 'after' }
    );
    if (!user) return res.status(404).json({ error: 'User not found' });

    res.json(user);
  } catch (err) { next(err); }
});

module.exports = router;
