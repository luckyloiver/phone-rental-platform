const express = require('express');
const mongoose = require('mongoose');
const crypto = require('crypto');
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const User = require('../models/User');
const auth = require('../middlewares/auth');
const admin = require('../middlewares/admin');
const {
  PLAN_DAYS, ORDER_STATUSES, OPEN_STATUSES, DELIVERY_FEE,
  PAYMENT_METHODS, bestValue, daysBetween,
} = require('../constants');

const router = express.Router();
router.use(auth);

const isValidId = (id) => mongoose.Types.ObjectId.isValid(id);

const CLOSED_STATUSES = ['cancelled', 'completed', 'refunded'];

function isoDate(d = new Date()) {
  return d.toISOString().slice(0, 10);
}

function addDays(dateStr, days) {
  const d = new Date(`${dateStr}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

const isValidDateStr = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(`${s}T00:00:00Z`));

/** ISO-8601 week key, e.g. "2026-W36". Weeks belong to the year of their Thursday. */
function isoWeekKey(date) {
  const d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const day = d.getUTCDay() || 7;              // Sun=0 → 7, so Mon=1…Sun=7
  d.setUTCDate(d.getUTCDate() + 4 - day);      // shift to that week's Thursday
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const week = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(week).padStart(2, '0')}`;
}

/** Give reserved units back to the catalog, exactly once per order. */
async function releaseStock(order) {
  if (order.stockReleased) return;
  await Promise.all(order.items.map(i =>
    Product.updateOne({ _id: i.product }, { $inc: { stock: i.qty } })
  ));
  order.stockReleased = true;
}

/* ---------------- checkout ---------------- */

router.post('/', async (req, res, next) => {
  const reserved = [];   // rollback log: [{ product, qty }]

  try {
    const user = await User.findById(req.userId);
    if (!user) return res.status(401).json({ error: 'Account no longer exists' });

    const cart = await Cart.findOne({ user: req.userId }).populate('items.product');
    if (!cart || !cart.items.length) {
      return res.status(400).json({ error: 'Your cart is empty' });
    }

    // Address: explicit in the request, else the saved profile.
    const address = String(
      req.body.address ||
      [user.profile?.address, user.profile?.city, user.profile?.zip].filter(Boolean).join(', ')
    ).trim();

    if (!address) {
      return res.status(400).json({ error: 'A delivery address is required' });
    }

    const startDate = req.body.startDate || isoDate();
    if (!isValidDateStr(startDate)) {
      return res.status(400).json({ error: 'startDate must be YYYY-MM-DD' });
    }
    if (startDate < isoDate()) {
      return res.status(400).json({ error: 'startDate cannot be in the past' });
    }

    // The customer picks the return date; fall back to a 7-day window if a
    // client somehow omits it. Pricing is driven by the day count below.
    const endDate = req.body.endDate || addDays(startDate, 7);
    if (!isValidDateStr(endDate)) {
      return res.status(400).json({ error: 'endDate must be YYYY-MM-DD' });
    }
    if (endDate < startDate) {
      return res.status(400).json({ error: 'endDate cannot be before startDate' });
    }

    const days = daysBetween(startDate, endDate);

    const live = cart.items.filter(i => i.product && i.product.active);
    if (!live.length) {
      return res.status(409).json({ error: 'Every item in your cart is no longer available' });
    }

    // Reserve stock item by item. A conditional $inc means two
    // simultaneous checkouts can't oversell the last unit.
    const items = [];
    for (const line of live) {
      const p = line.product;
      const updated = await Product.findOneAndUpdate(
        { _id: p._id, stock: { $gte: line.qty } },
        { $inc: { stock: -line.qty } },
        { returnDocument: 'after' }
      );

      if (!updated) {
        // Hand back whatever we already took, then report the clash.
        await Promise.all(reserved.map(r =>
          Product.updateOne({ _id: r.product }, { $inc: { stock: r.qty } })
        ));
        return res.status(409).json({
          error: `${p.name} no longer has ${line.qty} unit${line.qty === 1 ? '' : 's'} available`,
        });
      }

      reserved.push({ product: p._id, qty: line.qty });
      items.push({
        product: p._id,
        name: p.name,
        cat: p.cat,
        plan: line.plan,
        qty: line.qty,
        rate: bestValue(p, days),
        deposit: p.deposit,
      });
    }

    const rent = items.reduce((s, i) => s + i.rate * i.qty, 0);
    const deposit = items.reduce((s, i) => s + i.deposit * i.qty, 0);

    const order = await Order.create({
      user: user._id,
      userEmail: user.email,
      userName: user.name,
      items,
      rent,
      deposit,
      delivery: DELIVERY_FEE,
      total: rent + deposit + DELIVERY_FEE,
      address,
      startDate,
      endDate,
      days,
      status: 'pending',
      statusHistory: [{ status: 'pending', at: new Date() }],
    });

    cart.items = [];
    await cart.save();

    res.status(201).json(order);
  } catch (err) {
    // Never leave stock reserved against an order that failed to save.
    await Promise.all(reserved.map(r =>
      Product.updateOne({ _id: r.product }, { $inc: { stock: r.qty } })
    )).catch(() => {});
    next(err);
  }
});

/* ---------------- reads ---------------- */

router.get('/mine', async (req, res, next) => {
  try {
    const orders = await Order.find({ user: req.userId }).sort({ createdAt: -1 });
    res.json({ orders, count: orders.length });
  } catch (err) { next(err); }
});

// Admin: every order, newest first, optionally filtered by status.
router.get('/', auth, admin, async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.status && ORDER_STATUSES.includes(req.query.status)) {
      filter.status = req.query.status;
    }
    const orders = await Order.find(filter).sort({ createdAt: -1 });
    res.json({ orders, count: orders.length });
  } catch (err) { next(err); }
});

// Admin reporting. Declared before /:id so "reports" isn't read as an id.
router.get('/reports/summary', auth, admin, async (req, res, next) => {
  try {
    const orders = await Order.find({});
    const billable = orders.filter(o => o.status !== 'cancelled');

    const revenue = billable.reduce((s, o) => s + o.rent + o.delivery, 0);
    const depositsHeld = orders
      .filter(o => !CLOSED_STATUSES.includes(o.status))
      .reduce((s, o) => s + o.deposit, 0);
    const activeRentals = orders.filter(o => ['delivered', 'active'].includes(o.status)).length;

    const byDevice = {};
    const byCategory = {};
    billable.forEach(o => o.items.forEach(i => {
      const value = i.rate * i.qty;
      byDevice[i.name] = (byDevice[i.name] || 0) + value;
      byCategory[i.cat] = (byCategory[i.cat] || 0) + value;
    }));

    const byStatus = {};
    orders.forEach(o => { byStatus[o.status] = (byStatus[o.status] || 0) + 1; });

    // Revenue over time, keyed by when payment landed (falling back to when
    // the order was placed). Fed to the admin Week / Month / Year toggle.
    const byWeek = {};
    const byMonth = {};
    const byYear = {};
    billable.forEach(o => {
      const when = o.paidAt || o.createdAt;
      if (!when) return;
      const d = new Date(when);
      const value = o.rent + o.delivery;
      const mo = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
      const yr = String(d.getUTCFullYear());
      byWeek[isoWeekKey(d)] = (byWeek[isoWeekKey(d)] || 0) + value;
      byMonth[mo] = (byMonth[mo] || 0) + value;
      byYear[yr] = (byYear[yr] || 0) + value;
    });

    const products = await Product.find({ active: true }).select('name grade stock');
    const unitsOnShelf = products.reduce((s, p) => s + p.stock, 0);

    const unitsRentedOut = orders
      .filter(o => OPEN_STATUSES.includes(o.status))
      .reduce((s, o) => s + o.items.reduce((n, i) => n + i.qty, 0), 0);

    res.json({
      revenue,
      depositsHeld,
      orderCount: orders.length,
      activeRentals,
      unitsOnShelf,
      unitsRentedOut,
      lowStock: products.filter(p => p.stock > 0 && p.stock <= 2).length,
      outOfStock: products.filter(p => p.stock === 0).length,
      byDevice,
      byCategory,
      byStatus,
      byWeek,
      byMonth,
      byYear,
      byGrade: {
        'Like New': products.filter(p => p.grade === 'Like New').length,
        Good: products.filter(p => p.grade === 'Good').length,
        Fair: products.filter(p => p.grade === 'Fair').length,
      },
    });
  } catch (err) { next(err); }
});

router.get('/:id', async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) return res.status(400).json({ error: 'Invalid order id' });

    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });

    const me = await User.findById(req.userId).select('role');
    const owns = String(order.user) === String(req.userId);
    if (!owns && me?.role !== 'admin') {
      return res.status(403).json({ error: 'Not your order' });
    }

    res.json(order);
  } catch (err) { next(err); }
});

/* ---------------- customer actions ---------------- */

/**
 * Simulated payment. No real gateway: we record the (mock) payment and move
 * the order out of "pending" straight to "payment-confirmed". Owner-only and
 * guarded so a booking can't be paid twice.
 */
router.post('/:id/pay', async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) return res.status(400).json({ error: 'Invalid order id' });

    const method = PAYMENT_METHODS.includes(req.body.method) ? req.body.method : 'gcash';

    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (String(order.user) !== String(req.userId)) {
      return res.status(403).json({ error: 'Not your order' });
    }
    if (order.paid || order.status !== 'pending') {
      return res.status(409).json({ error: 'This booking has already been paid' });
    }

    order.paid = true;
    order.paidAt = new Date();
    order.payment = {
      method,
      ref: `PAY-${crypto.randomBytes(4).toString('hex').toUpperCase()}`,
      amount: order.total,
    };
    order.status = 'payment-confirmed';
    order.statusHistory.push({ status: 'payment-confirmed', at: new Date() });
    await order.save();
    res.json(order);
  } catch (err) { next(err); }
});

router.post('/:id/return', async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) return res.status(400).json({ error: 'Invalid order id' });

    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (String(order.user) !== String(req.userId)) {
      return res.status(403).json({ error: 'Not your order' });
    }
    if (!['delivered', 'active'].includes(order.status)) {
      return res.status(409).json({ error: `Cannot request a return while the order is "${order.status}"` });
    }

    order.status = 'return-requested';
    order.statusHistory.push({ status: 'return-requested', at: new Date() });
    await order.save();
    res.json(order);
  } catch (err) { next(err); }
});

router.post('/:id/extend', async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) return res.status(400).json({ error: 'Invalid order id' });

    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (String(order.user) !== String(req.userId)) {
      return res.status(403).json({ error: 'Not your order' });
    }
    if (!['delivered', 'active'].includes(order.status)) {
      return res.status(409).json({ error: 'Only an active rental can be extended' });
    }

    const days = Math.max(...order.items.map(i => PLAN_DAYS[i.plan] || 7));
    order.endDate = addDays(order.endDate, days);
    await order.save();
    res.json({ order, days });
  } catch (err) { next(err); }
});

router.post('/:id/cancel', async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) return res.status(400).json({ error: 'Invalid order id' });

    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (String(order.user) !== String(req.userId)) {
      return res.status(403).json({ error: 'Not your order' });
    }
    if (order.status !== 'pending') {
      return res.status(409).json({ error: 'Only a pending booking can be cancelled' });
    }

    await releaseStock(order);
    order.status = 'cancelled';
    order.statusHistory.push({ status: 'cancelled', at: new Date() });
    await order.save();
    res.json(order);
  } catch (err) { next(err); }
});

/* ---------------- admin actions ---------------- */

router.patch('/:id/status', auth, admin, async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) return res.status(400).json({ error: 'Invalid order id' });

    const { status } = req.body;
    if (!ORDER_STATUSES.includes(status)) {
      return res.status(400).json({ error: `status must be one of: ${ORDER_STATUSES.join(', ')}` });
    }

    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });

    // Closing an order hands its units back to the catalog.
    if (CLOSED_STATUSES.includes(status)) await releaseStock(order);

    order.status = status;
    order.statusHistory.push({ status, at: new Date() });
    await order.save();
    res.json(order);
  } catch (err) { next(err); }
});

module.exports = router;
