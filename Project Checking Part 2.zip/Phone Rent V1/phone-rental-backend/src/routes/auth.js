const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { OAuth2Client } = require('google-auth-library');
const User = require('../models/User');
const auth = require('../middlewares/auth');

// ---- Google OAuth Client ----
const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

const TOKEN_TTL = '7d';
const MIN_PASSWORD = 6;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function signToken(user) {
  return jwt.sign(
    { userId: user._id, email: user.email, name: user.name },
    process.env.JWT_SECRET,
    { expiresIn: TOKEN_TTL }
  );
}

// ============================================================
// 1. REGISTER – Create a new user account
// ============================================================
router.post('/register', async (req, res, next) => {
  try {
    const name = String(req.body.name || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email and password are all required' });
    }
    if (!EMAIL_RE.test(email)) {
      return res.status(400).json({ error: 'That email address looks invalid' });
    }
    if (password.length < MIN_PASSWORD) {
      return res.status(400).json({ error: `Password must be at least ${MIN_PASSWORD} characters` });
    }

    const existing = await User.findOne({ email });
    if (existing) return res.status(409).json({ error: 'Email already registered' });

    const hashed = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, password: hashed });

    res.status(201).json({ token: signToken(user), user });
  } catch (err) { next(err); }
});

// ============================================================
// 2. LOGIN – Email and password authentication
// ============================================================
router.post('/login', async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const user = await User.findOne({ email });
    if (!user || !user.password) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ error: 'Invalid credentials' });

    res.json({ token: signToken(user), user });
  } catch (err) { next(err); }
});

// ============================================================
// 3. GOOGLE LOGIN – OAuth 2.0 authentication
// ============================================================
router.post('/google', async (req, res, next) => {
  try {
    // Check if Google OAuth is configured
    if (!process.env.GOOGLE_CLIENT_ID) {
      return res.status(503).json({ error: 'Google sign-in is not configured on this server' });
    }

    const { token: googleToken } = req.body;
    if (!googleToken) return res.status(400).json({ error: 'Missing Google credential' });

    // Verify the Google ID token
    let payload;
    try {
      const ticket = await client.verifyIdToken({
        idToken: googleToken,
        audience: process.env.GOOGLE_CLIENT_ID,
      });
      payload = ticket.getPayload();
    } catch (err) {
      console.error('Google token verification failed:', err.message);
      return res.status(401).json({ error: 'Google authentication failed' });
    }

    const { email, name, picture, sub: googleId, email_verified: emailVerified } = payload;

    if (!email) {
      return res.status(400).json({ error: 'That Google account has no email address' });
    }
    // Accounts are matched by email below, so an unverified address would let
    // anyone who can create it take over an existing local account.
    if (!emailVerified) {
      return res.status(403).json({ error: 'Verify your email with Google first, then try again' });
    }

    // Find or create user
    let user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      // Create new user from Google data. No password field at all — a
      // Google-only account can never match in the email/password route.
      user = await User.create({
        name: name || email.split('@')[0],
        email,
        googleId,
        avatar: picture || undefined,
      });
      console.log(`✅ New user created via Google: ${email}`);
    } else if (!user.googleId) {
      // Link Google identity to existing local account
      user.googleId = googleId;
      if (picture && !user.avatar) user.avatar = picture;
      await user.save();
      console.log(`🔗 Google linked to existing user: ${email}`);
    }

    // Same shape as /login and /register: the full document, with toJSON
    // stripping the password hash and mapping _id → id. Returning a subset
    // here would drop `profile`, which checkout reads for the address.
    res.json({ token: signToken(user), user });
  } catch (err) { next(err); }
});

// ============================================================
// 4. GET CURRENT USER – Protected route
// ============================================================
router.get('/me', auth, async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) return res.status(401).json({ error: 'Account no longer exists' });
    res.json(user);
  } catch (err) { next(err); }
});

module.exports = router;