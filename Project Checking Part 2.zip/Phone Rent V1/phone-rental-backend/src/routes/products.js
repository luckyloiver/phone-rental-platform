const express = require('express');
const mongoose = require('mongoose');
const Product = require('../models/Product');
const Review = require('../models/Review');
const Order = require('../models/Order');
const auth = require('../middlewares/auth');
const admin = require('../middlewares/admin');
const { CATEGORIES, GRADES, QUALIFYING_REVIEW_STATUSES } = require('../constants');

const router = express.Router();

const isValidId = (id) => mongoose.Types.ObjectId.isValid(id);

/** Recompute a product's denormalized rating aggregates from its reviews. */
async function refreshProductRating(productId) {
  const [agg] = await Review.aggregate([
    { $match: { product: new mongoose.Types.ObjectId(String(productId)) } },
    { $group: { _id: null, avg: { $avg: '$rating' }, count: { $sum: 1 } } },
  ]);
  const avgRating = agg ? Math.round(agg.avg * 10) / 10 : 0;
  const reviewCount = agg ? agg.count : 0;
  await Product.updateOne({ _id: productId }, { $set: { avgRating, reviewCount } });
  return { avgRating, reviewCount };
}

/** Pull only the writable product fields off a request body. */
function pickProductFields(body) {
  const out = {};
  const strings = ['name', 'brand', 'cat', 'grade', 'desc', 'image'];
  const numbers = ['daily', 'weekly', 'monthly', 'deposit', 'stock'];

  strings.forEach(k => { if (body[k] !== undefined) out[k] = String(body[k]).trim(); });
  numbers.forEach(k => {
    if (body[k] === undefined) return;
    const n = Number(body[k]);
    if (Number.isFinite(n)) out[k] = Math.max(0, Math.round(n));
  });

  if (body.specs && typeof body.specs === 'object') out.specs = body.specs;
  if (Array.isArray(body.included)) out.included = body.included.map(String);

  return out;
}

function validateProduct(fields, { partial = false } = {}) {
  const errors = [];
  const need = (k) => !partial || fields[k] !== undefined;

  if (need('name')  && !fields.name)  errors.push('name is required');
  if (need('brand') && !fields.brand) errors.push('brand is required');
  if (fields.cat   !== undefined && !CATEGORIES.includes(fields.cat)) errors.push(`cat must be one of: ${CATEGORIES.join(', ')}`);
  if (fields.grade !== undefined && !GRADES.includes(fields.grade))   errors.push(`grade must be one of: ${GRADES.join(', ')}`);

  ['daily', 'weekly', 'monthly', 'deposit'].forEach(k => {
    if (need(k) && fields[k] === undefined) errors.push(`${k} is required`);
  });

  return errors;
}

/* ---------------- public reads ---------------- */

// GET /api/products?cat=phone&brand=Apple&grade=Good&q=pro&maxWeekly=2500&sort=price-asc
router.get('/', async (req, res, next) => {
  try {
    const { cat, brand, grade, q, maxWeekly, sort } = req.query;
    const filter = { active: true };

    if (cat && cat !== 'all' && CATEGORIES.includes(cat)) filter.cat = cat;
    if (brand && brand !== 'all') filter.brand = brand;
    if (grade && grade !== 'all' && GRADES.includes(grade)) filter.grade = grade;

    const max = Number(maxWeekly);
    if (Number.isFinite(max) && max > 0) filter.weekly = { $lte: max };

    if (q) {
      // Escape regex metacharacters so a stray "(" can't 500 the route.
      const safe = String(q).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const rx = new RegExp(safe, 'i');
      filter.$or = [{ name: rx }, { brand: rx }, { desc: rx }];
    }

    const sorts = {
      'price-asc':  { weekly: 1 },
      'price-desc': { weekly: -1 },
      'name':       { name: 1 },
      'stock':      { stock: -1 },
      'featured':   { createdAt: 1 },
    };

    const products = await Product.find(filter).sort(sorts[sort] || sorts.featured);
    res.json({ products, count: products.length });
  } catch (err) { next(err); }
});

router.get('/:id', async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) return res.status(400).json({ error: 'Invalid product id' });
    const product = await Product.findById(req.params.id);
    if (!product || !product.active) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
  } catch (err) { next(err); }
});

/* ---------------- reviews ---------------- */

// Public: a device's reviews, newest first, plus the current aggregates.
router.get('/:id/reviews', async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) return res.status(400).json({ error: 'Invalid product id' });
    const reviews = await Review.find({ product: req.params.id }).sort({ createdAt: -1 });
    const product = await Product.findById(req.params.id).select('avgRating reviewCount');
    res.json({
      reviews,
      count: product?.reviewCount ?? reviews.length,
      avgRating: product?.avgRating ?? 0,
    });
  } catch (err) { next(err); }
});

// Verified renters only: create or update the caller's review for a device.
router.post('/:id/reviews', auth, async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) return res.status(400).json({ error: 'Invalid product id' });

    const rating = Math.round(Number(req.body.rating));
    if (!Number.isFinite(rating) || rating < 1 || rating > 5) {
      return res.status(400).json({ error: 'rating must be a whole number from 1 to 5' });
    }
    const comment = String(req.body.comment || '').trim().slice(0, 1000);

    const product = await Product.findById(req.params.id);
    if (!product || !product.active) return res.status(404).json({ error: 'Product not found' });

    // The gate: the caller must own an order for this device that has at
    // least reached them (delivered or later).
    const rented = await Order.exists({
      user: req.userId,
      'items.product': req.params.id,
      status: { $in: QUALIFYING_REVIEW_STATUSES },
    });
    if (!rented) {
      return res.status(403).json({ error: 'Only customers who have rented this device can review it' });
    }

    const review = await Review.findOneAndUpdate(
      { product: req.params.id, user: req.userId },
      { $set: { rating, comment, userName: req.user?.name || '' } },
      { new: true, upsert: true, setDefaultsOnInsert: true }
    );

    const { avgRating, reviewCount } = await refreshProductRating(req.params.id);
    res.status(201).json({ review, avgRating, reviewCount });
  } catch (err) { next(err); }
});

/* ---------------- admin writes ---------------- */

router.post('/', auth, admin, async (req, res, next) => {
  try {
    const fields = pickProductFields(req.body);
    const errors = validateProduct(fields);
    if (errors.length) return res.status(400).json({ error: errors.join('; ') });

    const product = await Product.create(fields);
    res.status(201).json(product);
  } catch (err) { next(err); }
});

router.put('/:id', auth, admin, async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) return res.status(400).json({ error: 'Invalid product id' });

    const fields = pickProductFields(req.body);
    const errors = validateProduct(fields, { partial: true });
    if (errors.length) return res.status(400).json({ error: errors.join('; ') });

    const product = await Product.findByIdAndUpdate(
      req.params.id,
      { $set: fields },
      { returnDocument: 'after', runValidators: true }
    );
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
  } catch (err) { next(err); }
});

// Relative stock adjustment: { delta: 1 } or { delta: -1 }.
router.patch('/:id/stock', auth, admin, async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) return res.status(400).json({ error: 'Invalid product id' });

    const delta = Number(req.body.delta);
    if (!Number.isFinite(delta) || delta === 0) {
      return res.status(400).json({ error: 'delta must be a non-zero number' });
    }

    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found' });

    product.stock = Math.max(0, product.stock + Math.round(delta));
    await product.save();
    res.json(product);
  } catch (err) { next(err); }
});

// Soft delete — order history keeps referencing the document.
router.delete('/:id', auth, admin, async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) return res.status(400).json({ error: 'Invalid product id' });

    const product = await Product.findByIdAndUpdate(
      req.params.id,
      { $set: { active: false } },
      { returnDocument: 'after' }
    );
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json({ ok: true, id: product.id });
  } catch (err) { next(err); }
});

module.exports = router;
