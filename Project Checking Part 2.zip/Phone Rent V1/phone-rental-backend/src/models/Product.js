const mongoose = require('mongoose');
const { CATEGORIES, GRADES } = require('../constants');

const productSchema = new mongoose.Schema({
  name:  { type: String, required: true, trim: true },
  brand: { type: String, required: true, trim: true },
  cat:   { type: String, required: true, enum: CATEGORIES },
  grade: { type: String, required: true, enum: GRADES, default: 'Good' },

  // Rental rates in pesos.
  daily:   { type: Number, required: true, min: 0 },
  weekly:  { type: Number, required: true, min: 0 },
  monthly: { type: Number, required: true, min: 0 },

  deposit: { type: Number, required: true, min: 0 },
  stock:   { type: Number, required: true, min: 0, default: 0 },

  desc:     { type: String, default: '' },
  specs:    { type: Map, of: String, default: {} },
  included: { type: [String], default: [] },
  image:    { type: String, default: '' },

  // Denormalized review aggregates, recomputed whenever a review is written.
  avgRating:   { type: Number, default: 0 },
  reviewCount: { type: Number, default: 0 },

  // Soft delete: keeps historical orders readable after a device is
  // pulled from the catalog.
  active: { type: Boolean, default: true },
}, { timestamps: true });

productSchema.index({ cat: 1, brand: 1 });
productSchema.index({ name: 'text', desc: 'text' });

// Expose `id` and drop __v so the frontend keeps using numeric-ish ids
// via a single `id` field instead of _id.
productSchema.set('toJSON', {
  virtuals: true,
  versionKey: false,
  transform: (_doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    return ret;
  },
});

module.exports = mongoose.model('Product', productSchema);
