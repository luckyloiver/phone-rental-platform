const mongoose = require('mongoose');
const { CATEGORIES, PLANS, ORDER_STATUSES } = require('../constants');

/* Line items snapshot the name, rate and deposit at booking time so
   later catalog price changes never rewrite order history. */
const orderItemSchema = new mongoose.Schema({
  product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  name:    { type: String, required: true },
  cat:     { type: String, enum: CATEGORIES },
  plan:    { type: String, enum: PLANS, required: true },
  qty:     { type: Number, required: true, min: 1 },
  rate:    { type: Number, required: true, min: 0 },
  deposit: { type: Number, required: true, min: 0 },
}, { _id: false });

/* Simulated payment record — populated once the customer completes the
   mock checkout. There is no real gateway. */
const paymentSchema = new mongoose.Schema({
  method: { type: String },
  ref:    { type: String },
  amount: { type: Number, min: 0 },
}, { _id: false });

const orderSchema = new mongoose.Schema({
  user:      { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  userEmail: { type: String, required: true },
  userName:  { type: String, default: '' },

  items: { type: [orderItemSchema], required: true, validate: v => v.length > 0 },

  rent:     { type: Number, required: true, min: 0 },
  deposit:  { type: Number, required: true, min: 0 },
  delivery: { type: Number, required: true, min: 0 },
  total:    { type: Number, required: true, min: 0 },

  address:   { type: String, required: true },
  startDate: { type: String, required: true },   // YYYY-MM-DD
  endDate:   { type: String, required: true },
  days:      { type: Number, min: 1, default: 1 },

  status: { type: String, enum: ORDER_STATUSES, default: 'pending', index: true },

  // Simulated payment. `paid` flips true once the mock checkout completes,
  // which is also when the order leaves "pending".
  paid:    { type: Boolean, default: false },
  paidAt:  { type: Date },
  payment: { type: paymentSchema, default: undefined },

  statusHistory: {
    type: [{
      status: { type: String, enum: ORDER_STATUSES },
      at:     { type: Date, default: Date.now },
      _id:    false,
    }],
    default: [],
  },

  // Set once stock has been returned to the catalog, so a cancel
  // followed by another cancel can't double-restock.
  stockReleased: { type: Boolean, default: false },
}, { timestamps: true });

orderSchema.set('toJSON', {
  virtuals: true,
  versionKey: false,
  transform: (_doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    return ret;
  },
});

module.exports = mongoose.model('Order', orderSchema);
