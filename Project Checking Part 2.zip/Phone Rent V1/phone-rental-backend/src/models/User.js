const mongoose = require('mongoose');

/* Saved delivery details. Required (address at minimum) before checkout. */
const profileSchema = new mongoose.Schema({
  phone:   { type: String, default: '' },
  address: { type: String, default: '' },
  city:    { type: String, default: '' },
  zip:     { type: String, default: '' },
}, { _id: false });

const userSchema = new mongoose.Schema({
  name:     { type: String, required: true, trim: true },
  email:    { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String },
  googleId: { type: String },
  avatar:   { type: String },
  role:     { type: String, enum: ['user', 'admin'], default: 'user' },
  profile:  { type: profileSchema, default: () => ({}) },
}, { timestamps: true });

// Defence in depth: even if a route forgets .select('-password'), the
// hash never leaves the process in a JSON response.
userSchema.set('toJSON', {
  virtuals: true,
  versionKey: false,
  transform: (_doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.password;
    return ret;
  },
});

module.exports = mongoose.model('User', userSchema);
