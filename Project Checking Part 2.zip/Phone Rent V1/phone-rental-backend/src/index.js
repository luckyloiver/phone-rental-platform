require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');

const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const cartRoutes = require('./routes/cart');
const orderRoutes = require('./routes/orders');
const userRoutes = require('./routes/users');

/* ---------------- environment ---------------- */

const REQUIRED_ENV = ['MONGODB_URI', 'JWT_SECRET'];
const missing = REQUIRED_ENV.filter(k => !process.env[k]);
if (missing.length) {
  console.error(`❌ Missing required environment variable(s): ${missing.join(', ')}`);
  console.error('   Copy phone-rental-backend/.env.example to .env and fill in the values.');
  process.exit(1);
}
if (!process.env.GOOGLE_CLIENT_ID) {
  console.warn('⚠️  GOOGLE_CLIENT_ID is not set — "Sign in with Google" will fail, other auth is fine.');
}

const PORT = Number(process.env.PORT) || 5000;
const FRONTEND_DIR = path.join(__dirname, '../../phone-rental-frontend');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

// Express 5 leaves req.body as undefined when a request carries no body
// (Express 4 defaulted it to {}). Normalise it once here so no route has
// to guard every property read.
app.use((req, _res, next) => {
  if (req.body === undefined) req.body = {};
  next();
});

/* ---------------- database ---------------- */

mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('❌ MongoDB error:', err.message));

/* ---------------- API ---------------- */

app.get('/api/health', (req, res) => {
  const states = ['disconnected', 'connected', 'connecting', 'disconnecting'];
  res.json({
    ok: true,
    db: states[mongoose.connection.readyState] || 'unknown',
    uptime: Math.round(process.uptime()),
  });
});

app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/users', userRoutes);

// Unmatched API path — answer in JSON, never with the HTML shell.
app.use('/api', (req, res) => {
  res.status(404).json({ error: `No such endpoint: ${req.method} ${req.originalUrl}` });
});

/* ---------------- static frontend ---------------- */

// Serves index.html at "/" plus products.html, cart.html, css/, js/, assets/.
app.use(express.static(FRONTEND_DIR));

// Soft fallback: an unknown non-API path lands on the homepage rather
// than a bare error page.
app.use((req, res) => {
  res.sendFile(path.join(FRONTEND_DIR, 'index.html'));
});

/* ---------------- errors ---------------- */

// Four arguments: this is Express's error handler, not a route.
app.use((err, req, res, _next) => {
  if (err?.name === 'ValidationError') {
    const detail = Object.values(err.errors || {}).map(e => e.message).join('; ');
    return res.status(400).json({ error: detail || 'Validation failed' });
  }
  if (err?.name === 'CastError') {
    return res.status(400).json({ error: `Invalid value for ${err.path}` });
  }
  if (err?.code === 11000) {
    return res.status(409).json({ error: 'That record already exists' });
  }

  console.error('❌ Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`🚀 DiaLux server running on http://localhost:${PORT}`);
});
